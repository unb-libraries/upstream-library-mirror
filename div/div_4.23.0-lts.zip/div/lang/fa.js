/*
Copyright (c) 2003-2023, CKSource Holding sp. z o.o. All rights reserved.
CKEditor 4 LTS ("Long Term Support") is available under the terms of the Extended Support Model.
*/
CKEDITOR.plugins.setLang( 'div', 'fa', {
	IdInputLabel: 'شناسه',
	advisoryTitleInputLabel: 'عنوان مشاوره',
	cssClassInputLabel: 'کلاس​های شیوه​نامه',
	edit: 'ویرایش Div',
	inlineStyleInputLabel: 'سبک درون​خطی(Inline Style)',
	langDirLTRLabel: 'چپ به راست (LTR)',
	langDirLabel: 'جهت نوشتاری زبان',
	langDirRTLLabel: 'راست به چپ (RTL)',
	languageCodeInputLabel: ' کد زبان',
	remove: 'حذف Div',
	styleSelectLabel: 'سبک',
	title: 'ایجاد یک محل DIV',
	toolbar: 'ایجاد یک محل DIV'
} );
