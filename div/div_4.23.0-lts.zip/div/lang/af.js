/*
Copyright (c) 2003-2023, CKSource Holding sp. z o.o. All rights reserved.
CKEditor 4 LTS ("Long Term Support") is available under the terms of the Extended Support Model.
*/
CKEDITOR.plugins.setLang( 'div', 'af', {
	IdInputLabel: 'Id',
	advisoryTitleInputLabel: 'Aanbevole Titel',
	cssClassInputLabel: 'CSS klasse',
	edit: 'Wysig Div',
	inlineStyleInputLabel: 'Inlyn Styl',
	langDirLTRLabel: 'Links na regs (LTR)',
	langDirLabel: 'Skryfrigting',
	langDirRTLLabel: 'Regs na links (RTL)',
	languageCodeInputLabel: ' Taalkode',
	remove: 'Verwyder Div',
	styleSelectLabel: 'Styl',
	title: 'Skep Div houer',
	toolbar: 'Skep Div houer'
} );
