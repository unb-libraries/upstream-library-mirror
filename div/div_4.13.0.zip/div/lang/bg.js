/*
Copyright (c) 2003-2019, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'div', 'bg', {
	IdInputLabel: 'Id',
	advisoryTitleInputLabel: 'Заглавие',
	cssClassInputLabel: 'Класове за CSS',
	edit: 'Промяна на Div',
	inlineStyleInputLabel: 'В редица',
	langDirLTRLabel: 'От ляво надясно (LTR)',
	langDirLabel: 'Посока на езика',
	langDirRTLLabel: 'От дясно наляво (RTL)',
	languageCodeInputLabel: ' Код на езика',
	remove: 'Премахване на Div',
	styleSelectLabel: 'Стил',
	title: 'Създаване на Div контейнер',
	toolbar: 'Създаване на Div контейнер'
} );
