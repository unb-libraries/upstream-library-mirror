/*
Copyright (c) 2003-2019, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'div', 'ka', {
	IdInputLabel: 'Id',
	advisoryTitleInputLabel: 'სათაური',
	cssClassInputLabel: 'CSS კლასები',
	edit: 'Div-ის რედაქტირება',
	inlineStyleInputLabel: 'თანდართული სტილი',
	langDirLTRLabel: 'მარცხნიდან მარჯვნიც (LTR)',
	langDirLabel: 'ენის მინართულება',
	langDirRTLLabel: 'მარჯვნიდან მარცხნივ (RTL)',
	languageCodeInputLabel: 'ენის კოდი',
	remove: 'Div-ის წაშლა',
	styleSelectLabel: 'სტილი',
	title: 'Div კონტეინერის შექმნა',
	toolbar: 'Div კონტეინერის შექმნა'
} );
