/*
Copyright (c) 2003-2019, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'div', 'fi', {
	IdInputLabel: 'Id',
	advisoryTitleInputLabel: 'Ohjeistava otsikko',
	cssClassInputLabel: 'Tyylitiedoston luokat',
	edit: 'Muokkaa Diviä',
	inlineStyleInputLabel: 'Sisätyyli',
	langDirLTRLabel: 'Vasemmalta oikealle (LTR)',
	langDirLabel: 'Kielen suunta',
	langDirRTLLabel: 'Oikealta vasemmalle (RTL)',
	languageCodeInputLabel: ' Kielen koodi',
	remove: 'Poista Div',
	styleSelectLabel: 'Tyyli',
	title: 'Luo div-kehikko',
	toolbar: 'Luo div-kehikko'
} );
