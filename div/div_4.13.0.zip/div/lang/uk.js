/*
Copyright (c) 2003-2019, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'div', 'uk', {
	IdInputLabel: 'Ідентифікатор',
	advisoryTitleInputLabel: 'Зміст випливаючої підказки',
	cssClassInputLabel: 'Клас CSS',
	edit: 'Редагувати блок',
	inlineStyleInputLabel: 'Вписаний стиль',
	langDirLTRLabel: 'Зліва направо (LTR)',
	langDirLabel: 'Напрямок мови',
	langDirRTLLabel: 'Справа наліво (RTL)',
	languageCodeInputLabel: 'Код мови',
	remove: 'Видалити блок',
	styleSelectLabel: 'Стиль CSS',
	title: 'Створити блок-контейнер',
	toolbar: 'Створити блок-контейнер'
} );
