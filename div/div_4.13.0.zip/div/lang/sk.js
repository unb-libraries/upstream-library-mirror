/*
Copyright (c) 2003-2019, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'div', 'sk', {
	IdInputLabel: 'Id',
	advisoryTitleInputLabel: 'Pomocný titulok',
	cssClassInputLabel: 'Triedy štýlu',
	edit: 'Upraviť Div',
	inlineStyleInputLabel: 'Inline štýl',
	langDirLTRLabel: 'Zľava doprava (LTR)',
	langDirLabel: 'Smer jazyka',
	langDirRTLLabel: 'Zprava doľava (RTL)',
	languageCodeInputLabel: 'Kód jazyka',
	remove: 'Odstrániť Div',
	styleSelectLabel: 'Štýl',
	title: 'Vytvoriť Div kontajner',
	toolbar: 'Vytvoriť Div kontajner'
} );
