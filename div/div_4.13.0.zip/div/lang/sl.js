/*
Copyright (c) 2003-2019, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'div', 'sl', {
	IdInputLabel: 'Id',
	advisoryTitleInputLabel: 'Predlagani naslov',
	cssClassInputLabel: 'Razredi slogovne predloge',
	edit: 'Uredi div',
	inlineStyleInputLabel: 'Slog v vrstici',
	langDirLTRLabel: 'Od leve proti desni (LTR)',
	langDirLabel: 'Smer jezika',
	langDirRTLLabel: 'Od desne proti levi (RTL)',
	languageCodeInputLabel: 'Koda jezika',
	remove: 'Odstrani div',
	styleSelectLabel: 'Slog',
	title: 'Ustvari vsebnik div',
	toolbar: 'Ustvari vsebnik div'
} );
