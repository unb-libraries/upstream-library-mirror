/*
Copyright (c) 2003-2019, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'div', 'tr', {
	IdInputLabel: 'Id',
	advisoryTitleInputLabel: 'Tavsiye Başlığı',
	cssClassInputLabel: 'Stilltipi Sınıfı',
	edit: 'Div Düzenle',
	inlineStyleInputLabel: 'Inline Stili',
	langDirLTRLabel: 'Soldan sağa (LTR)',
	langDirLabel: 'Dil Yönü',
	langDirRTLLabel: 'Sağdan sola (RTL)',
	languageCodeInputLabel: ' Dil Kodu',
	remove: 'Div Kaldır',
	styleSelectLabel: 'Stil',
	title: 'Div İçeriği Oluştur',
	toolbar: 'Div İçeriği Oluştur'
} );
