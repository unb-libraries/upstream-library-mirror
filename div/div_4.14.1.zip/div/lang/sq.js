/*
Copyright (c) 2003-2020, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'div', 'sq', {
	IdInputLabel: 'Id',
	advisoryTitleInputLabel: 'Titulli Këshillimorit',
	cssClassInputLabel: 'CSS Klasat',
	edit: 'Redakto Div',
	inlineStyleInputLabel: 'Stili Brendshëm',
	langDirLTRLabel: 'Nga e majta në të djathë (LTR)',
	langDirLabel: 'Drejtimi Gjuhës',
	langDirRTLLabel: 'Nga e djathta në të majtë (RTL)',
	languageCodeInputLabel: 'Kodi i Gjuhës',
	remove: 'Largo Div',
	styleSelectLabel: 'Stili',
	title: 'Krijo Përmbajtës Div',
	toolbar: 'Krijo Përmbajtës Div'
} );
