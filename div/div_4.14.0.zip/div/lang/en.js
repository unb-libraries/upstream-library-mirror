/*
Copyright (c) 2003-2020, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'div', 'en', {
	IdInputLabel: 'Id',
	advisoryTitleInputLabel: 'Advisory Title',
	cssClassInputLabel: 'Stylesheet Classes',
	edit: 'Edit Div',
	inlineStyleInputLabel: 'Inline Style',
	langDirLTRLabel: 'Left to Right (LTR)',
	langDirLabel: 'Language Direction',
	langDirRTLLabel: 'Right to Left (RTL)',
	languageCodeInputLabel: ' Language Code',
	remove: 'Remove Div',
	styleSelectLabel: 'Style',
	title: 'Create Div Container',
	toolbar: 'Create Div Container'
} );
